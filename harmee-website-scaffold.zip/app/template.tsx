"use client"

import type React from "react"

import { motion, AnimatePresence } from "framer-motion"
import { usePathname } from "next/navigation"
import { useSettings } from "@/lib/use-settings"

export default function Template({ children }: { children: React.ReactNode }) {
  const pathname = usePathname()
  const { settings } = useSettings()

  // Skip animation on consent page
  if (pathname === "/" || pathname === "/bye") {
    return <>{children}</>
  }

  const variants = settings.reduceMotion
    ? {
        initial: { opacity: 0 },
        animate: { opacity: 1 },
        exit: { opacity: 0 },
      }
    : {
        initial: { opacity: 0, y: 6, filter: "blur(2px)" },
        animate: { opacity: 1, y: 0, filter: "blur(0px)" },
        exit: { opacity: 0, y: -6, filter: "blur(2px)" },
      }

  return (
    <AnimatePresence mode="wait" initial={false}>
      <motion.div
        key={pathname}
        initial={variants.initial}
        animate={variants.animate}
        exit={variants.exit}
        transition={{
          duration: settings.reduceMotion ? 0.01 : 0.22,
          ease: [0.22, 1, 0.36, 1],
        }}
        style={{ height: "100%" }}
      >
        {children}
      </motion.div>
    </AnimatePresence>
  )
}
