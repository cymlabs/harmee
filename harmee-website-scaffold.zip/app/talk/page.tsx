"use client"

import { useState, useRef, useEffect } from "react"
import { AppShell } from "@/components/app-shell"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { motion, AnimatePresence } from "framer-motion"
import { useSettings } from "@/lib/use-settings"
import { Send, Mic, MessageCircle } from "lucide-react"

const talkModes = [
  { id: "1:1", label: "1:1 Chat" },
  { id: "trio", label: "Trio Text" },
  { id: "voice", label: "Voice Booth" },
  { id: "auto", label: "Autopilot" },
  { id: "memory", label: "Memories" },
]

const initialMessages = [{ id: 1, role: "harmee", content: "Hey there. What's on your mind today?" }]

export default function TalkPage() {
  const [activeMode, setActiveMode] = useState("1:1")
  const [message, setMessage] = useState("")
  const [messages, setMessages] = useState(initialMessages)
  const [isTyping, setIsTyping] = useState(false)
  const scrollRef = useRef<HTMLDivElement>(null)
  const { settings } = useSettings()

  const handleSend = () => {
    if (!message.trim()) return

    const newMessage = { id: Date.now(), role: "user", content: message }
    setMessages((prev) => [...prev, newMessage])
    setMessage("")
    setIsTyping(true)

    setTimeout(() => {
      setIsTyping(false)
      setMessages((prev) => [
        ...prev,
        { id: Date.now() + 1, role: "harmee", content: "Interesting... tell me more about that." },
      ])
    }, 1500)
  }

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }, [messages, isTyping])

  const motionProps = settings.reduceMotion ? {} : { whileTap: { scale: 0.97 } }

  return (
    <AppShell>
      <div className="flex h-[calc(100vh-7rem)] flex-col gap-4 p-4 lg:p-6">
        <div className="harmee-chamber p-4">
          <div className="relative z-10 flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[var(--surface-inset)]">
                <MessageCircle className="h-5 w-5" />
              </div>
              <div>
                <h2 className="font-bold tracking-tight">Talk Mode</h2>
                <p className="text-xs text-muted-foreground">{messages.length} messages in session</p>
              </div>
            </div>
            <div className="harmee-pill">
              <span className="harmee-dot" />
              <span className="text-xs font-medium">{activeMode}</span>
            </div>
          </div>

          <div className="relative z-10 mt-4 flex flex-wrap gap-2">
            {talkModes.map((mode) => (
              <motion.button
                key={mode.id}
                onClick={() => setActiveMode(mode.id)}
                className={`rounded-full px-4 py-2 text-sm font-medium transition-all ${
                  activeMode === mode.id
                    ? "bg-foreground text-background shadow-sm"
                    : "bg-[var(--surface-inset)] text-muted-foreground hover:text-foreground"
                }`}
                {...motionProps}
              >
                {mode.label}
              </motion.button>
            ))}
          </div>
        </div>

        <div className="harmee-secondary flex flex-1 flex-col overflow-hidden">
          <ScrollArea className="flex-1 p-4" ref={scrollRef}>
            <div className="space-y-4">
              <AnimatePresence initial={false}>
                {messages.map((msg) => (
                  <motion.div
                    key={msg.id}
                    initial={settings.reduceMotion ? { opacity: 0 } : { opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.18, ease: [0.4, 0, 0.2, 1] }}
                    className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                  >
                    <div
                      className={`max-w-[80%] rounded-2xl px-4 py-3 ${
                        msg.role === "user"
                          ? "bg-foreground text-background"
                          : "bg-[var(--surface-inset)] text-foreground"
                      }`}
                    >
                      <p className="text-sm leading-relaxed">{msg.content}</p>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>

              <AnimatePresence>
                {isTyping && (
                  <motion.div
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -8 }}
                    className="flex justify-start"
                  >
                    <div className="flex items-center gap-1 rounded-2xl bg-[var(--surface-inset)] px-4 py-3">
                      <motion.span
                        className="h-2 w-2 rounded-full bg-muted-foreground"
                        animate={{ opacity: [0.4, 1, 0.4] }}
                        transition={{ duration: 1, repeat: Number.POSITIVE_INFINITY, delay: 0 }}
                      />
                      <motion.span
                        className="h-2 w-2 rounded-full bg-muted-foreground"
                        animate={{ opacity: [0.4, 1, 0.4] }}
                        transition={{ duration: 1, repeat: Number.POSITIVE_INFINITY, delay: 0.2 }}
                      />
                      <motion.span
                        className="h-2 w-2 rounded-full bg-muted-foreground"
                        animate={{ opacity: [0.4, 1, 0.4] }}
                        transition={{ duration: 1, repeat: Number.POSITIVE_INFINITY, delay: 0.4 }}
                      />
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </ScrollArea>

          {/* Input bar */}
          <div className="border-t border-[var(--border-subtle)] p-4">
            <div className="harmee-row p-2">
              <Input
                placeholder="Type your message..."
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSend()}
                className="h-10 flex-1 border-0 bg-transparent text-sm focus-visible:ring-0"
              />
              <motion.div {...motionProps}>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-10 w-10 shrink-0 text-muted-foreground hover:text-foreground"
                >
                  <Mic className="h-4 w-4" />
                </Button>
              </motion.div>
              <motion.div {...motionProps}>
                <Button
                  size="icon"
                  className="h-10 w-10 shrink-0 rounded-lg bg-foreground text-background hover:bg-foreground/90"
                  onClick={handleSend}
                  disabled={!message.trim()}
                >
                  <Send className="h-4 w-4" />
                </Button>
              </motion.div>
            </div>
          </div>
        </div>
      </div>
    </AppShell>
  )
}
