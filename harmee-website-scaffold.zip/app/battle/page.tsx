"use client"

import { useState } from "react"
import { AppShell } from "@/components/app-shell"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { motion, AnimatePresence } from "framer-motion"
import { useSettings } from "@/lib/use-settings"
import { Swords, Trophy, History, Flame, Shield, Clock } from "lucide-react"

const battleModes = [
  { id: "quick", name: "Quick Fight", description: "Jump into instant action", icon: Flame },
  { id: "scenario", name: "Scenarios", description: "Structured challenges", icon: Shield },
  { id: "ladder", name: "Ladder", description: "Competitive ranking", icon: Trophy },
  { id: "replay", name: "Replays", description: "Review past battles", icon: History },
]

const moveSet = [
  { id: "punch", name: "Punch", damage: 10, cooldown: 0, icon: "👊" },
  { id: "kick", name: "Kick", damage: 15, cooldown: 1, icon: "🦵" },
  { id: "special", name: "Special", damage: 30, cooldown: 3, icon: "⚡" },
]

export default function BattlePage() {
  const [selectedMode, setSelectedMode] = useState<string | null>(null)
  const [inBattle, setInBattle] = useState(false)
  const [cooldowns, setCooldowns] = useState<Record<string, number>>({})
  const [health, setHealth] = useState({ player: 100, enemy: 100 })
  const { settings } = useSettings()

  const motionProps = settings.reduceMotion
    ? {}
    : {
        initial: { opacity: 0, y: 12 },
        animate: { opacity: 1, y: 0 },
        whileHover: { y: -2, transition: { duration: 0.12 } },
        whileTap: { scale: 0.97 },
      }

  const handleAttack = (move: (typeof moveSet)[0]) => {
    if (cooldowns[move.id] > 0) return

    setHealth((prev) => ({
      ...prev,
      enemy: Math.max(0, prev.enemy - move.damage),
    }))

    if (move.cooldown > 0) {
      setCooldowns((prev) => ({ ...prev, [move.id]: move.cooldown }))
      const interval = setInterval(() => {
        setCooldowns((prev) => {
          const newCd = (prev[move.id] || 0) - 1
          if (newCd <= 0) {
            clearInterval(interval)
            const { [move.id]: _, ...rest } = prev
            return rest
          }
          return { ...prev, [move.id]: newCd }
        })
      }, 1000)
    }
  }

  const startBattle = () => {
    setInBattle(true)
    setHealth({ player: 100, enemy: 100 })
    setCooldowns({})
  }

  return (
    <AppShell>
      <div className="harmee-page-container">
        <div className="mb-6">
          <h1 className="mb-2 text-2xl font-bold tracking-tight text-foreground">Battle Arena</h1>
          <p className="text-sm text-muted-foreground">Choose your battle mode and dominate</p>
        </div>

        <AnimatePresence mode="wait">
          {!inBattle ? (
            <motion.div key="mode-select" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <div className="harmee-chamber mb-6 p-6">
                <div className="relative z-10">
                  <div className="flex items-start justify-between gap-6">
                    <div className="flex items-center gap-4">
                      <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-[var(--surface-inset)]">
                        <Swords className="h-6 w-6" />
                      </div>
                      <div>
                        <h2 className="text-lg font-bold tracking-tight">Select Mode</h2>
                        <p className="text-sm text-muted-foreground">Choose your challenge type</p>
                      </div>
                    </div>
                    {selectedMode && (
                      <div className="harmee-pill">
                        <span className="harmee-dot" />
                        <span className="text-xs font-medium capitalize">{selectedMode}</span>
                      </div>
                    )}
                  </div>

                  {/* Mode cards grid */}
                  <div className="mt-6 grid gap-3 sm:grid-cols-2">
                    {battleModes.map((mode) => {
                      const Icon = mode.icon
                      const isSelected = selectedMode === mode.id
                      return (
                        <motion.div key={mode.id} {...(settings.reduceMotion ? {} : { whileTap: { scale: 0.97 } })}>
                          <div
                            className={`harmee-row cursor-pointer transition-all ${
                              isSelected ? "bg-foreground text-background" : ""
                            }`}
                            onClick={() => setSelectedMode(mode.id)}
                          >
                            <div className="harmee-row-left">
                              <Icon className={`h-5 w-5 ${isSelected ? "text-background" : "text-muted-foreground"}`} />
                              <div>
                                <p className="text-sm font-medium">{mode.name}</p>
                                <p className={`text-xs ${isSelected ? "text-background/70" : "text-muted-foreground"}`}>
                                  {mode.description}
                                </p>
                              </div>
                            </div>
                          </div>
                        </motion.div>
                      )
                    })}
                  </div>

                  <motion.div className="mt-6" {...(settings.reduceMotion ? {} : { whileTap: { scale: 0.97 } })}>
                    <Button
                      className="harmee-button w-full gap-2 bg-foreground text-background hover:bg-foreground/90 sm:w-auto"
                      onClick={startBattle}
                      disabled={!selectedMode}
                    >
                      <Swords className="h-4 w-4" />
                      Start Battle
                    </Button>
                  </motion.div>
                </div>
              </div>
            </motion.div>
          ) : (
            <motion.div key="battle" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <div className="harmee-chamber mb-6 overflow-hidden p-0">
                <div className="relative z-10">
                  {/* Health bars */}
                  <div className="flex items-center justify-between border-b border-[var(--border-subtle)] p-4">
                    <div className="flex-1">
                      <p className="mb-1 text-xs font-medium text-muted-foreground">YOUR HARMEE</p>
                      <div className="h-3 overflow-hidden rounded-full bg-[var(--surface-inset)]">
                        <motion.div
                          className="h-full bg-emerald-500"
                          initial={{ width: "100%" }}
                          animate={{ width: `${health.player}%` }}
                          transition={{ duration: 0.3 }}
                        />
                      </div>
                    </div>
                    <div className="px-4 text-lg font-bold text-muted-foreground">VS</div>
                    <div className="flex-1">
                      <p className="mb-1 text-right text-xs font-medium text-muted-foreground">OPPONENT</p>
                      <div className="h-3 overflow-hidden rounded-full bg-[var(--surface-inset)]">
                        <motion.div
                          className="h-full bg-rose-500"
                          initial={{ width: "100%" }}
                          animate={{ width: `${health.enemy}%` }}
                          transition={{ duration: 0.3 }}
                        />
                      </div>
                    </div>
                  </div>

                  {/* Battle visualization */}
                  <div className="flex h-64 items-center justify-center bg-[var(--surface-inset)]">
                    <p className="text-sm text-muted-foreground">Battle visualization area</p>
                  </div>

                  {/* Move deck */}
                  <div className="flex gap-2 border-t border-[var(--border-subtle)] p-4">
                    {moveSet.map((move) => {
                      const onCooldown = cooldowns[move.id] > 0
                      return (
                        <motion.div
                          key={move.id}
                          className="flex-1"
                          {...(settings.reduceMotion || onCooldown ? {} : { whileTap: { scale: 0.95 } })}
                        >
                          <Button
                            variant="outline"
                            className={`harmee-button relative h-16 w-full flex-col gap-1 ${
                              onCooldown ? "opacity-50" : ""
                            }`}
                            onClick={() => handleAttack(move)}
                            disabled={onCooldown}
                          >
                            <span className="text-lg">{move.icon}</span>
                            <span className="text-xs font-medium">{move.name}</span>
                            <Badge variant="secondary" className="absolute right-1 top-1 h-5 px-1 text-[10px]">
                              {move.damage} DMG
                            </Badge>
                            {onCooldown && (
                              <div className="absolute inset-0 flex items-center justify-center rounded-md bg-background/80">
                                <Clock className="mr-1 h-3 w-3" />
                                <span className="text-xs font-mono">{cooldowns[move.id]}s</span>
                              </div>
                            )}
                          </Button>
                        </motion.div>
                      )
                    })}
                  </div>
                </div>
              </div>

              {/* Secondary - exit button */}
              <Button variant="outline" className="harmee-button bg-transparent" onClick={() => setInBattle(false)}>
                Exit Battle
              </Button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </AppShell>
  )
}
