"use client"

import { AppShell } from "@/components/app-shell"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { motion } from "framer-motion"
import { useSettings } from "@/lib/use-settings"
import { Info, Download, FileText, ImageIcon, Mail, Newspaper } from "lucide-react"

const pressKitItems = [
  { title: "Brand Assets", description: "Logos and visual identity", icon: ImageIcon },
  { title: "Screenshots", description: "High-resolution images", icon: FileText },
  { title: "Press Release", description: "Latest announcements", icon: Newspaper },
  { title: "Contact", description: "Media inquiries", icon: Mail },
]

export default function AboutPage() {
  const { settings } = useSettings()
  const motionProps = settings.reduceMotion ? {} : { whileTap: { scale: 0.97 } }

  return (
    <AppShell>
      <div className="harmee-page-container">
        <div className="mx-auto max-w-4xl">
          <div className="harmee-chamber mb-6 p-8 text-center">
            <div className="relative z-10">
              <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-[var(--surface-inset)]">
                <span className="text-2xl font-bold">H</span>
              </div>
              <h1 className="mb-2 font-mono text-4xl font-bold text-foreground">HARMEE</h1>
              <Badge variant="outline" className="mb-4">
                by CYMLABS
              </Badge>
              <p className="mx-auto max-w-md text-pretty text-sm leading-relaxed text-muted-foreground">
                A stress-relief arena where characters react, talk back, and evolve.
              </p>
            </div>
          </div>

          <div className="harmee-secondary mb-6 p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[var(--surface-inset)]">
                <Info className="h-5 w-5" />
              </div>
              <h2 className="text-xl font-bold text-foreground">About CYMLABS</h2>
            </div>
            <div className="space-y-4 text-sm leading-relaxed text-muted-foreground">
              <p>
                CYMLABS is a digital experience studio focused on creating innovative interactive experiences that blend
                technology with emotional design.
              </p>
              <p>
                Our mission is to explore new ways of human-computer interaction, particularly in the realm of emotional
                expression and stress relief.
              </p>
              <p>
                HARMEE represents our vision of a future where digital companions can provide meaningful outlets for
                emotional release and personal growth.
              </p>
            </div>
          </div>

          <div className="mb-6">
            <h2 className="mb-4 flex items-center gap-2 text-xl font-bold text-foreground">
              <Download className="h-5 w-5" />
              Press Kit
            </h2>
            <div className="grid gap-4 sm:grid-cols-2">
              {pressKitItems.map((item) => {
                const Icon = item.icon
                return (
                  <motion.div key={item.title} {...motionProps}>
                    <div className="harmee-secondary harmee-tilt-card cursor-pointer p-4">
                      <div className="flex items-start gap-3">
                        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[var(--surface-inset)]">
                          <Icon className="h-5 w-5 text-muted-foreground" />
                        </div>
                        <div>
                          <h3 className="mb-1 font-medium text-foreground">{item.title}</h3>
                          <p className="text-sm text-muted-foreground">{item.description}</p>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                )
              })}
            </div>
          </div>

          <div className="harmee-secondary p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs font-medium text-muted-foreground">VERSION</p>
                <p className="text-sm font-semibold text-foreground">1.0.0</p>
              </div>
              <motion.div {...motionProps}>
                <Button variant="outline" className="harmee-button bg-transparent">
                  View Changelog
                </Button>
              </motion.div>
            </div>
          </div>
        </div>
      </div>
    </AppShell>
  )
}
