"use client"

import { AppShell } from "@/components/app-shell"
import { useState, useEffect } from "react"
import { ArenaStage } from "@/components/arena-stage"
import { ArenaHUD } from "@/components/arena-hud"
import { DialoguePanel } from "@/components/dialogue-panel"
import { ActionDeck } from "@/components/action-deck"

type Mood = "Calm" | "Annoyed" | "Enraged"

interface DialogueResponse {
  message: string
  mood: Mood
  consequenceHint: string
}

const responses: DialogueResponse[] = [
  {
    message: "Why do you keep doing this to me? Don't you understand?",
    mood: "Annoyed",
    consequenceHint: "This may increase rage",
  },
  {
    message: "Ow! That actually hurt... why?",
    mood: "Calm",
    consequenceHint: "Harmee seems confused",
  },
  {
    message: "STOP IT! I've had enough of this!",
    mood: "Enraged",
    consequenceHint: "Harmee is losing patience",
  },
  {
    message: "Is this supposed to make you feel better?",
    mood: "Annoyed",
    consequenceHint: "Harmee is questioning your actions",
  },
  {
    message: "I don't deserve this treatment...",
    mood: "Calm",
    consequenceHint: "Harmee seems hurt",
  },
]

const choices = ["Be Understanding", "Question Back", "Stay Silent"]

export default function ArenaPage() {
  const [hitCount, setHitCount] = useState(0)
  const [score, setScore] = useState(0)
  const [combo, setCombo] = useState(0)
  const [mood, setMood] = useState<Mood>("Calm")
  const [currentDialogue, setCurrentDialogue] = useState<DialogueResponse>(responses[0])
  const [showChoices, setShowChoices] = useState(false)

  const handleHit = () => {
    setHitCount((prev) => prev + 1)
    setScore((prev) => prev + 10)
    setCombo((prev) => Math.min(prev + 1, 10))

    // Pick random response
    const randomResponse = responses[Math.floor(Math.random() * responses.length)]
    setCurrentDialogue(randomResponse)
    setMood(randomResponse.mood)
    setShowChoices(true)
  }

  const handleKick = () => {
    setHitCount((prev) => prev + 1)
    setScore((prev) => prev + 15)
    setCombo((prev) => Math.min(prev + 2, 10))

    const randomResponse = responses[Math.floor(Math.random() * responses.length)]
    setCurrentDialogue(randomResponse)
    setMood(randomResponse.mood)
    setShowChoices(true)

    // Trigger stage animation
    const trigger = document.getElementById("stage-hit-trigger")
    trigger?.click()
  }

  const handleShove = () => {
    setHitCount((prev) => prev + 1)
    setScore((prev) => prev + 25)
    setCombo((prev) => Math.min(prev + 3, 10))

    const randomResponse = responses[Math.floor(Math.random() * responses.length)]
    setCurrentDialogue(randomResponse)
    setMood("Enraged")
    setShowChoices(true)

    // Trigger stage animation
    const trigger = document.getElementById("stage-hit-trigger")
    trigger?.click()
  }

  const handleReset = () => {
    setHitCount(0)
    setScore(0)
    setCombo(0)
    setMood("Calm")
    setCurrentDialogue(responses[0])
    setShowChoices(false)
  }

  const handleChoiceSelect = (choice: string) => {
    setShowChoices(false)
    // Could add more complex logic here based on choice
  }

  // Reset combo after 3 seconds of inactivity
  useEffect(() => {
    if (combo > 0) {
      const timer = setTimeout(() => {
        setCombo(0)
      }, 3000)
      return () => clearTimeout(timer)
    }
  }, [combo, hitCount])

  return (
    <AppShell>
      <div className="flex h-[calc(100vh-3.5rem)] flex-col gap-4 p-4 lg:p-6">
        {/* Top: HUD */}
        <ArenaHUD mood={mood} combo={combo} score={score} hits={hitCount} />

        {/* Main content area */}
        <div className="flex flex-1 gap-4 overflow-hidden lg:gap-6">
          {/* Center: Stage (HERO module) */}
          <div className="flex flex-1 items-center justify-center">
            <ArenaStage onHit={handleHit} hitCount={hitCount} />
          </div>

          {/* Right: Dialogue + Actions */}
          <div className="flex w-full flex-col gap-4 lg:w-80">
            <DialoguePanel
              message={currentDialogue.message}
              choices={choices}
              consequenceHint={currentDialogue.consequenceHint}
              showChoices={showChoices}
              onChoiceSelect={handleChoiceSelect}
            />

            <ActionDeck
              onHit={handleHit}
              onKick={handleKick}
              onShove={handleShove}
              onReset={handleReset}
              score={score}
              shoveUnlockScore={50}
            />
          </div>
        </div>
      </div>
    </AppShell>
  )
}
