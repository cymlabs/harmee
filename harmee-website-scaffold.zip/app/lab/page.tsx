"use client"

import { useState } from "react"
import { AppShell } from "@/components/app-shell"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { motion, AnimatePresence } from "framer-motion"
import { useSettings } from "@/lib/use-settings"
import { cn } from "@/lib/utils"
import { Palette, Shirt, Sparkles, Mic, Brain, Database, Download, ChevronRight, FlaskConical } from "lucide-react"

const labSections = [
  { id: "skin", name: "Skin Studio", icon: Palette, description: "Customize appearance" },
  { id: "gear", name: "Gear", icon: Shirt, description: "Equip accessories" },
  { id: "reactions", name: "Reactions", icon: Sparkles, description: "Configure responses" },
  { id: "voice", name: "Voice", icon: Mic, description: "Adjust voice settings" },
  { id: "persona", name: "Persona", icon: Brain, description: "Define personality" },
  { id: "memories", name: "Memories", icon: Database, description: "Manage memories" },
  { id: "export", name: "Import/Export", icon: Download, description: "Backup & restore" },
]

export default function LabPage() {
  const [activeSection, setActiveSection] = useState("skin")
  const { settings } = useSettings()

  const activeConfig = labSections.find((s) => s.id === activeSection)
  const ActiveIcon = activeConfig?.icon || Palette

  return (
    <AppShell>
      <div className="flex h-[calc(100vh-7rem)] flex-col gap-4 p-4 lg:flex-row lg:p-6">
        <div className="w-full shrink-0 lg:w-64">
          <div className="harmee-chamber p-4">
            <div className="relative z-10">
              <div className="mb-4 flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[var(--surface-inset)]">
                  <FlaskConical className="h-5 w-5" />
                </div>
                <div>
                  <h2 className="font-bold tracking-tight">The Lab</h2>
                  <p className="text-xs text-muted-foreground">Customize your Harmee</p>
                </div>
              </div>

              <ScrollArea className="h-full">
                <div className="flex flex-row gap-1 lg:flex-col">
                  {labSections.map((section) => {
                    const Icon = section.icon
                    const isActive = activeSection === section.id
                    return (
                      <motion.div key={section.id} {...(settings.reduceMotion ? {} : { whileTap: { scale: 0.97 } })}>
                        <Button
                          variant="ghost"
                          className={cn(
                            "h-auto w-full justify-start gap-3 px-3 py-3 text-left transition-all duration-150",
                            isActive
                              ? "bg-foreground text-background"
                              : "text-muted-foreground hover:bg-[var(--surface-inset)] hover:text-foreground",
                          )}
                          onClick={() => setActiveSection(section.id)}
                        >
                          <Icon className="h-4 w-4 shrink-0" />
                          <div className="hidden flex-1 lg:block">
                            <p className="text-sm font-medium">{section.name}</p>
                            <p className={cn("text-xs", isActive ? "text-background/70" : "text-muted-foreground")}>
                              {section.description}
                            </p>
                          </div>
                          {isActive && <ChevronRight className="hidden h-4 w-4 lg:block" />}
                        </Button>
                      </motion.div>
                    )
                  })}
                </div>
              </ScrollArea>
            </div>
          </div>
        </div>

        <div className="flex-1">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeSection}
              initial={settings.reduceMotion ? { opacity: 0 } : { opacity: 0, x: 12 }}
              animate={{ opacity: 1, x: 0 }}
              exit={settings.reduceMotion ? { opacity: 0 } : { opacity: 0, x: -12 }}
              transition={{ duration: 0.18, ease: [0.4, 0, 0.2, 1] }}
              className="h-full"
            >
              <div className="harmee-secondary flex h-full flex-col p-6">
                <div className="mb-6 flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[var(--surface-inset)]">
                    <ActiveIcon className="h-5 w-5 text-foreground" />
                  </div>
                  <div>
                    <h2 className="text-xl font-bold text-foreground">{activeConfig?.name}</h2>
                    <p className="text-sm text-muted-foreground">{activeConfig?.description}</p>
                  </div>
                </div>
                <div className="flex flex-1 items-center justify-center rounded-xl bg-[var(--surface-inset)]">
                  <div className="text-center">
                    <ActiveIcon className="mx-auto mb-3 h-12 w-12 text-muted-foreground/30" />
                    <p className="text-sm text-muted-foreground">{activeConfig?.name} customization interface</p>
                  </div>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </AppShell>
  )
}
