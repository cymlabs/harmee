"use client"

import { useState } from "react"
import { AppShell } from "@/components/app-shell"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { motion, AnimatePresence } from "framer-motion"
import { useSettings } from "@/lib/use-settings"
import {
  Drawer,
  DrawerClose,
  DrawerContent,
  DrawerDescription,
  DrawerFooter,
  DrawerHeader,
  DrawerTitle,
} from "@/components/ui/drawer"
import { Star, Sparkles, Crown, Zap, Users } from "lucide-react"

const harmees = [
  { id: 1, name: "Max", mood: "Defiant", level: 5, rarity: "common" },
  { id: 2, name: "Luna", mood: "Curious", level: 3, rarity: "rare" },
  { id: 3, name: "Rex", mood: "Aggressive", level: 7, rarity: "epic" },
  { id: 4, name: "Zara", mood: "Playful", level: 4, rarity: "legendary" },
]

const rarityConfig = {
  common: { icon: Star, color: "text-muted-foreground", bg: "bg-secondary" },
  rare: { icon: Sparkles, color: "text-blue-500", bg: "bg-blue-500/10" },
  epic: { icon: Crown, color: "text-purple-500", bg: "bg-purple-500/10" },
  legendary: { icon: Zap, color: "text-amber-500", bg: "bg-amber-500/10" },
}

const filters = ["All", "Common", "Rare", "Epic", "Legendary"]

export default function MyHarmeesPage() {
  const [selectedHarmee, setSelectedHarmee] = useState<number | null>(null)
  const [activeFilter, setActiveFilter] = useState("All")
  const { settings } = useSettings()

  const filteredHarmees =
    activeFilter === "All" ? harmees : harmees.filter((h) => h.rarity.toLowerCase() === activeFilter.toLowerCase())

  const motionProps = settings.reduceMotion
    ? {}
    : {
        initial: { opacity: 0, y: 12 },
        animate: { opacity: 1, y: 0 },
        whileHover: { y: -4, transition: { duration: 0.18 } },
        whileTap: { scale: 0.97 },
      }

  return (
    <AppShell>
      <div className="harmee-page-container">
        {/* Header */}
        <div className="mb-6">
          <h1 className="mb-2 text-2xl font-bold tracking-tight text-foreground">My Harmees</h1>
          <p className="text-sm text-muted-foreground">Your collection of stress-relief companions</p>
        </div>

        <div className="harmee-chamber mb-6 p-6">
          <div className="relative z-10">
            <div className="flex items-start justify-between gap-6">
              <div className="flex items-center gap-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-[var(--surface-inset)]">
                  <Users className="h-6 w-6" />
                </div>
                <div>
                  <h2 className="text-lg font-bold tracking-tight">Collection</h2>
                  <p className="text-sm text-muted-foreground">
                    {harmees.length} Harmees • {harmees.filter((h) => h.rarity === "legendary").length} Legendary
                  </p>
                </div>
              </div>
              <div className="harmee-pill">
                <span className="harmee-dot" />
                <span className="text-xs font-medium">{activeFilter}</span>
              </div>
            </div>

            {/* Filter pills */}
            <div className="mt-6 flex flex-wrap gap-2">
              {filters.map((filter) => (
                <motion.button
                  key={filter}
                  onClick={() => setActiveFilter(filter)}
                  className={`rounded-full px-4 py-2 text-sm font-medium transition-all ${
                    activeFilter === filter
                      ? "bg-foreground text-background shadow-sm"
                      : "bg-[var(--surface-inset)] text-muted-foreground hover:text-foreground"
                  }`}
                  {...(settings.reduceMotion ? {} : { whileTap: { scale: 0.97 } })}
                >
                  {filter}
                </motion.button>
              ))}
            </div>
          </div>
        </div>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          <AnimatePresence mode="popLayout">
            {filteredHarmees.map((harmee, index) => {
              const { icon: RarityIcon, color, bg } = rarityConfig[harmee.rarity as keyof typeof rarityConfig]
              return (
                <motion.div
                  key={harmee.id}
                  {...motionProps}
                  transition={{ delay: index * 0.05, duration: 0.18, ease: [0.4, 0, 0.2, 1] }}
                  layout
                >
                  <div
                    className="harmee-secondary harmee-tilt-card cursor-pointer overflow-hidden p-0"
                    onClick={() => setSelectedHarmee(harmee.id)}
                  >
                    {/* Character display area */}
                    <div className="relative flex aspect-square items-center justify-center bg-[var(--surface-inset)]">
                      <div className="text-4xl font-bold text-muted-foreground/20">{harmee.name[0]}</div>
                      <div className={`absolute right-3 top-3 flex items-center gap-1 rounded-full ${bg} px-2 py-1`}>
                        <RarityIcon className={`h-3 w-3 ${color}`} />
                        <span className={`text-xs font-medium capitalize ${color}`}>{harmee.rarity}</span>
                      </div>
                    </div>
                    {/* Info section */}
                    <div className="p-4">
                      <div className="mb-2 flex items-center justify-between">
                        <h3 className="font-semibold text-foreground">{harmee.name}</h3>
                        <Badge variant="outline" className="border-border/50 text-xs font-mono">
                          Lv.{harmee.level}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">{harmee.mood}</p>
                    </div>
                  </div>
                </motion.div>
              )
            })}
          </AnimatePresence>
        </div>

        {/* Empty state */}
        {filteredHarmees.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="harmee-secondary flex flex-col items-center justify-center py-20 text-center"
          >
            <div className="mb-4 rounded-full bg-[var(--surface-inset)] p-4">
              <Star className="h-8 w-8 text-muted-foreground/50" />
            </div>
            <h3 className="mb-2 font-semibold text-foreground">No Harmees Found</h3>
            <p className="text-sm text-muted-foreground">Try adjusting your filter</p>
          </motion.div>
        )}

        {/* Drawer - unchanged */}
        <Drawer open={selectedHarmee !== null} onOpenChange={() => setSelectedHarmee(null)}>
          <DrawerContent className="border-t border-border/50 bg-[var(--surface-elevated)] backdrop-blur-xl">
            <DrawerHeader className="text-center">
              <DrawerTitle className="text-xl font-bold text-foreground">
                {harmees.find((h) => h.id === selectedHarmee)?.name}
              </DrawerTitle>
              <DrawerDescription className="text-muted-foreground">View and manage your Harmee</DrawerDescription>
            </DrawerHeader>
            <div className="px-4 pb-4">
              <div className="mx-auto mb-6 flex aspect-square max-w-xs items-center justify-center rounded-2xl bg-[var(--surface-inset)]">
                <span className="text-6xl font-bold text-muted-foreground/20">
                  {harmees.find((h) => h.id === selectedHarmee)?.name[0]}
                </span>
              </div>
              <div className="mx-auto grid max-w-xs grid-cols-2 gap-4">
                <div className="rounded-xl bg-[var(--surface-inset)] p-4 text-center">
                  <p className="mb-1 text-xs font-medium uppercase tracking-wider text-muted-foreground">Mood</p>
                  <p className="font-semibold text-foreground">{harmees.find((h) => h.id === selectedHarmee)?.mood}</p>
                </div>
                <div className="rounded-xl bg-[var(--surface-inset)] p-4 text-center">
                  <p className="mb-1 text-xs font-medium uppercase tracking-wider text-muted-foreground">Level</p>
                  <p className="font-semibold text-foreground">{harmees.find((h) => h.id === selectedHarmee)?.level}</p>
                </div>
              </div>
            </div>
            <DrawerFooter>
              <DrawerClose asChild>
                <Button variant="outline" className="harmee-button w-full bg-transparent">
                  Close
                </Button>
              </DrawerClose>
            </DrawerFooter>
          </DrawerContent>
        </Drawer>
      </div>
    </AppShell>
  )
}
