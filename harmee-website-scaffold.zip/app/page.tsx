"use client"

import { useState, useEffect } from "react"
import { AnimatePresence } from "framer-motion"
import { useSettings } from "@/lib/use-settings"
import { HarmeeBackground } from "@/components/harmee-background"
import { CymLabsIntro } from "@/components/cymlabs-intro"
import { ConsentPopup } from "@/components/consent-popup"

export default function ConsentGate() {
  const { settings } = useSettings()
  const [showIntro, setShowIntro] = useState(true)
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#FAFAFC]">
        <div className="h-8 w-8 animate-pulse rounded-full bg-foreground/10" />
      </div>
    )
  }

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-[#FAFAFC]">
      {/* Background only shows after intro */}
      <AnimatePresence>{!showIntro && <HarmeeBackground />}</AnimatePresence>

      {/* Intro sequence */}
      <AnimatePresence mode="wait">
        {showIntro && (
          <CymLabsIntro key="intro" onComplete={() => setShowIntro(false)} skipAnimation={settings.reduceMotion} />
        )}
      </AnimatePresence>

      {/* Consent popup appears after intro */}
      <AnimatePresence>{!showIntro && <ConsentPopup key="popup" />}</AnimatePresence>
    </div>
  )
}
