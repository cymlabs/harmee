import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function ByePage() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-[#F6F6F6]">
      <div className="text-center">
        <h1 className="font-mono text-2xl font-bold text-foreground">Session ended.</h1>
        <p className="mt-2 text-sm text-muted-foreground">Thanks for using HARMEE.</p>
        <Link href="/" className="mt-6 inline-block">
          <Button variant="outline" className="h-8 px-4 text-xs bg-transparent">
            Return Home
          </Button>
        </Link>
      </div>
    </div>
  )
}
