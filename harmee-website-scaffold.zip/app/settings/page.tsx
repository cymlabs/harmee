"use client"

import { AppShell } from "@/components/app-shell"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { motion } from "framer-motion"
import { useSettings } from "@/lib/use-settings"
import { Volume2, VolumeX, Zap, ZapOff, Sparkles, RotateCcw, FileText, Bug, Mail } from "lucide-react"

export default function SettingsPage() {
  const { settings, updateSetting, resetSettings } = useSettings()

  const motionProps = settings.reduceMotion ? {} : { whileTap: { scale: 0.97 } }

  return (
    <AppShell>
      <div className="harmee-page-container">
        <div className="mb-6">
          <h1 className="mb-2 text-2xl font-bold tracking-tight text-foreground">Settings</h1>
          <p className="text-sm text-muted-foreground">Manage your HARMEE preferences</p>
        </div>

        <div className="mx-auto max-w-3xl space-y-6">
          <div className="harmee-chamber p-6">
            <div className="relative z-10">
              <div className="flex items-start justify-between gap-6">
                <div>
                  <h2 className="text-lg font-bold tracking-tight">Global</h2>
                  <p className="mt-1 text-sm text-muted-foreground">
                    Control the vibe: audio, motion, and visual intensity.
                  </p>
                </div>
                {/* Status pill */}
                <div className="harmee-pill">
                  <span className="harmee-dot" />
                  <span className="text-xs font-medium">{settings.liteMode ? "Lite" : "Impact"}</span>
                </div>
              </div>

              <div className="mt-6 grid gap-3">
                {/* Mute row */}
                <div className="harmee-row">
                  <div className="harmee-row-left">
                    {settings.mute ? <VolumeX className="h-5 w-5 opacity-60" /> : <Volume2 className="h-5 w-5" />}
                    <div>
                      <Label htmlFor="mute" className="text-sm font-medium">
                        Mute Audio
                      </Label>
                      <p className="text-xs text-muted-foreground">Disable sound effects and voice</p>
                    </div>
                  </div>
                  <Switch id="mute" checked={settings.mute} onCheckedChange={(c) => updateSetting("mute", c)} />
                </div>

                {/* Reduce Motion row */}
                <div className="harmee-row">
                  <div className="harmee-row-left">
                    <Sparkles className={`h-5 w-5 ${settings.reduceMotion ? "opacity-60" : ""}`} />
                    <div>
                      <Label htmlFor="reduce-motion" className="text-sm font-medium">
                        Reduce Motion
                      </Label>
                      <p className="text-xs text-muted-foreground">Minimize animations and transitions</p>
                    </div>
                  </div>
                  <Switch
                    id="reduce-motion"
                    checked={settings.reduceMotion}
                    onCheckedChange={(c) => updateSetting("reduceMotion", c)}
                  />
                </div>

                {/* Lite Mode row */}
                <div className="harmee-row">
                  <div className="harmee-row-left">
                    {settings.liteMode ? <ZapOff className="h-5 w-5 opacity-60" /> : <Zap className="h-5 w-5" />}
                    <div>
                      <Label htmlFor="lite-mode" className="text-sm font-medium">
                        Lite Mode
                      </Label>
                      <p className="text-xs text-muted-foreground">Fewer effects, faster feel</p>
                    </div>
                  </div>
                  <Switch
                    id="lite-mode"
                    checked={settings.liteMode}
                    onCheckedChange={(c) => updateSetting("liteMode", c)}
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="grid gap-6 md:grid-cols-2">
            <div className="harmee-secondary p-6">
              <h2 className="text-lg font-bold tracking-tight">Reset</h2>
              <p className="mt-1 text-sm text-muted-foreground">Restore defaults across the app.</p>
              <motion.div className="mt-4" {...motionProps}>
                <Button className="harmee-button w-full bg-transparent" variant="outline" onClick={resetSettings}>
                  <RotateCcw className="h-4 w-4" />
                  Reset All Settings
                </Button>
              </motion.div>
            </div>

            <div className="harmee-secondary p-6">
              <h2 className="text-lg font-bold tracking-tight">Support</h2>
              <p className="mt-1 text-sm text-muted-foreground">Docs, issues, and contact.</p>
              <div className="mt-4 grid gap-2">
                <motion.div {...motionProps}>
                  <Button className="harmee-button w-full justify-start bg-transparent" variant="outline">
                    <FileText className="h-4 w-4" /> View Documentation
                  </Button>
                </motion.div>
                <motion.div {...motionProps}>
                  <Button className="harmee-button w-full justify-start bg-transparent" variant="outline">
                    <Bug className="h-4 w-4" /> Report an Issue
                  </Button>
                </motion.div>
                <motion.div {...motionProps}>
                  <Button className="harmee-button w-full justify-start bg-transparent" variant="outline">
                    <Mail className="h-4 w-4" /> Contact Support
                  </Button>
                </motion.div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </AppShell>
  )
}
