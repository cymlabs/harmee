"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Card } from "@/components/ui/card"
import { useSettings } from "@/lib/use-settings"

interface StageResponse {
  text: string
  emotion: "neutral" | "hurt" | "angry" | "confused" | "sad"
}

const responses: StageResponse[] = [
  { text: "Ow! Why would you do that?", emotion: "hurt" },
  { text: "Stop it! That hurts!", emotion: "angry" },
  { text: "I don't understand... what did I do?", emotion: "confused" },
  { text: "Please... just leave me alone.", emotion: "sad" },
  { text: "You think this makes you stronger?", emotion: "angry" },
  { text: "Is this really what you want?", emotion: "confused" },
]

export function StagePlaceholder() {
  const { settings } = useSettings()
  const [hitCount, setHitCount] = useState(0)
  const [currentResponse, setCurrentResponse] = useState<StageResponse | null>(null)
  const [isShaking, setIsShaking] = useState(false)

  const handleHit = () => {
    // Increment hit counter
    setHitCount((prev) => prev + 1)

    // Pick random response
    const randomResponse = responses[Math.floor(Math.random() * responses.length)]
    setCurrentResponse(randomResponse)

    // Trigger shake animation
    setIsShaking(true)
    setTimeout(() => setIsShaking(false), 180)
  }

  return (
    <div className="relative flex h-full w-full flex-col items-center justify-center">
      {/* Stage container with idle animation */}
      <motion.div
        animate={
          isShaking
            ? {
                x: [0, -4, 4, -3, 3, -2, 2, 0],
                transition: { duration: 0.18 },
              }
            : settings.reduceMotion
              ? {}
              : {
                  y: [0, -2, 0],
                  transition: {
                    duration: 3,
                    repeat: Number.POSITIVE_INFINITY,
                    ease: "easeInOut",
                  },
                }
        }
        className="relative"
      >
        {/* Stage platform */}
        <Card className="relative flex h-80 w-80 items-center justify-center overflow-hidden border-border bg-gradient-to-b from-secondary/30 to-secondary/50 p-8 lg:h-96 lg:w-96">
          {/* Shimmer effect */}
          {!settings.liteMode && !settings.reduceMotion && (
            <motion.div
              className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent"
              animate={{
                x: ["-100%", "100%"],
              }}
              transition={{
                duration: 4,
                repeat: Number.POSITIVE_INFINITY,
                ease: "linear",
              }}
            />
          )}

          {/* Character placeholder */}
          <div className="z-10 flex flex-col items-center gap-4">
            <div className="h-32 w-32 rounded-full border-2 border-dashed border-border bg-background/50 backdrop-blur-sm" />
            <p className="font-mono text-xs text-muted-foreground">Character Stage</p>
            <p className="font-mono text-xs text-muted-foreground">Hits: {hitCount}</p>
          </div>
        </Card>

        {/* Dialogue bubble */}
        <AnimatePresence mode="wait">
          {currentResponse && (
            <motion.div
              key={currentResponse.text}
              initial={{ opacity: 0, y: 10, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -10, scale: 0.9 }}
              transition={{ duration: settings.reduceMotion ? 0 : 0.15 }}
              className="absolute -top-20 left-1/2 w-64 -translate-x-1/2"
            >
              <Card className="border-border bg-background p-4 shadow-lg">
                <p className="text-pretty text-sm leading-relaxed text-foreground">{currentResponse.text}</p>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>

      {/* Click glow effect on interaction */}
      {!settings.liteMode && !settings.reduceMotion && (
        <motion.div
          className="pointer-events-none absolute inset-0 rounded-lg"
          animate={
            isShaking
              ? {
                  boxShadow: [
                    "0 0 0 0 rgba(239, 68, 68, 0)",
                    "0 0 20px 10px rgba(239, 68, 68, 0.12)",
                    "0 0 0 0 rgba(239, 68, 68, 0)",
                  ],
                  transition: { duration: 0.4 },
                }
              : {}
          }
        />
      )}

      {/* Hidden button for external trigger */}
      <button id="stage-hit-trigger" onClick={handleHit} className="sr-only" aria-label="Hit character" />
    </div>
  )
}
