"use client"

import type React from "react"

import { motion } from "framer-motion"
import { forwardRef } from "react"
import { useSettings } from "@/lib/use-settings"
import { cn } from "@/lib/utils"

interface LiftCardProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode
  className?: string
  disabled?: boolean
}

export const LiftCard = forwardRef<HTMLDivElement, LiftCardProps>(
  ({ children, className, disabled, ...props }, ref) => {
    const { settings } = useSettings()

    const motionProps =
      settings.reduceMotion || disabled
        ? {}
        : {
            whileHover: { y: -2 },
            whileTap: { scale: 0.99 },
          }

    return (
      <motion.div
        ref={ref}
        {...motionProps}
        transition={{ type: "spring", stiffness: 420, damping: 34 }}
        className={cn("transition-shadow", className)}
        {...props}
      >
        {children}
      </motion.div>
    )
  },
)

LiftCard.displayName = "LiftCard"
