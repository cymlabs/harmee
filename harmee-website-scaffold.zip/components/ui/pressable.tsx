"use client"

import type React from "react"
import { motion, type HTMLMotionProps } from "framer-motion"
import { forwardRef } from "react"
import { useSettings } from "@/lib/use-settings"
import { cn } from "@/lib/utils"

interface PressableProps extends HTMLMotionProps<"div"> {
  children: React.ReactNode
  className?: string
  disabled?: boolean
}

export const Pressable = forwardRef<HTMLDivElement, PressableProps>(
  ({ children, className, disabled, ...props }, ref) => {
    const { settings } = useSettings()
    let reduceMotion = false
    try {
      reduceMotion = settings.reduceMotion
    } catch {
      // Use default if hook fails
    }

    const motionProps =
      reduceMotion || disabled
        ? {}
        : {
            whileHover: { y: -1 },
            whileTap: { scale: 0.98, y: 0 },
          }

    return (
      <motion.div
        ref={ref}
        {...motionProps}
        transition={{ type: "spring", stiffness: 500, damping: 35 }}
        className={cn("inline-block", className)}
        {...props}
      >
        {children}
      </motion.div>
    )
  },
)

Pressable.displayName = "Pressable"
