"use client"

import { useState, useRef, useEffect, useCallback, type ReactNode, type KeyboardEvent, createContext } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { cn } from "@/lib/utils"
import { useSettings } from "@/lib/use-settings"

// ============================================================================
// CONSTANTS
// ============================================================================

const HIGHLIGHT_PADDING = 4
const BORDER_WIDTH = 2
const TRANSITION_SPRING = { type: "spring", stiffness: 500, damping: 35 }
const TRANSITION_FAST = { duration: 0.15, ease: [0.32, 0.72, 0, 1] }
const SLIDER_HEIGHT = 120
const RAIL_HEIGHT = 40

// ============================================================================
// TYPES
// ============================================================================

export interface MagicRailItem {
  id: string
  icon?: ReactNode
  label?: string
  slider?: boolean // If true, this item morphs into a slider control
  sliderValue?: number // 0-100
  onSliderChange?: (value: number) => void
}

interface MagicRailProps {
  items: MagicRailItem[]
  activeId: string
  onChange: (id: string) => void
  className?: string
}

interface ItemBounds {
  left: number
  width: number
  height: number
}

// ============================================================================
// CONTEXT FOR SLIDER STATE
// ============================================================================

const MorphContext = createContext<{
  isMorphed: boolean
  sliderValue: number
  setSliderValue: (v: number) => void
}>({
  isMorphed: false,
  sliderValue: 50,
  setSliderValue: () => {},
})

// ============================================================================
// MAGIC RAIL COMPONENT
// ============================================================================

export function MagicRail({ items, activeId, onChange, className }: MagicRailProps) {
  const { settings } = useSettings()
  const reduceMotion = settings.reduceMotion

  const containerRef = useRef<HTMLDivElement>(null)
  const itemRefs = useRef<Map<string, HTMLButtonElement>>(new Map())

  const [hoveredId, setHoveredId] = useState<string | null>(null)
  const [bounds, setBounds] = useState<Map<string, ItemBounds>>(new Map())
  const [pressing, setPressing] = useState(false)

  // Slider state for morph control
  const activeItem = items.find((i) => i.id === activeId)
  const isMorphed = activeItem?.slider ?? false
  const [sliderValue, setSliderValue] = useState(activeItem?.sliderValue ?? 50)

  // Sync slider value with external prop
  useEffect(() => {
    if (activeItem?.sliderValue !== undefined) {
      setSliderValue(activeItem.sliderValue)
    }
  }, [activeItem?.sliderValue])

  // ============================================================================
  // MEASURE ITEM BOUNDS
  // ============================================================================

  const measureBounds = useCallback(() => {
    if (!containerRef.current) return

    const containerRect = containerRef.current.getBoundingClientRect()
    const newBounds = new Map<string, ItemBounds>()

    itemRefs.current.forEach((el, id) => {
      if (el) {
        const rect = el.getBoundingClientRect()
        newBounds.set(id, {
          left: rect.left - containerRect.left,
          width: rect.width,
          height: rect.height,
        })
      }
    })

    setBounds(newBounds)
  }, [])

  // Measure on mount and resize
  useEffect(() => {
    measureBounds()

    const observer = new ResizeObserver(measureBounds)
    if (containerRef.current) {
      observer.observe(containerRef.current)
    }

    return () => observer.disconnect()
  }, [measureBounds, items])

  // ============================================================================
  // HIGHLIGHT POSITION
  // ============================================================================

  const targetId = hoveredId ?? activeId
  const targetBounds = bounds.get(targetId)

  const highlightStyle = targetBounds
    ? {
        x: targetBounds.left - HIGHLIGHT_PADDING,
        width: targetBounds.width + HIGHLIGHT_PADDING * 2,
        height: isMorphed && targetId === activeId ? SLIDER_HEIGHT : targetBounds.height + HIGHLIGHT_PADDING * 2,
        y:
          isMorphed && targetId === activeId
            ? -(SLIDER_HEIGHT - RAIL_HEIGHT) / 2 - HIGHLIGHT_PADDING
            : -HIGHLIGHT_PADDING,
      }
    : { x: 0, width: 0, height: RAIL_HEIGHT, y: 0 }

  // ============================================================================
  // KEYBOARD NAVIGATION
  // ============================================================================

  const handleKeyDown = (e: KeyboardEvent<HTMLDivElement>) => {
    const currentIndex = items.findIndex((i) => i.id === activeId)
    let newIndex = currentIndex

    if (e.key === "ArrowRight" || e.key === "ArrowDown") {
      newIndex = Math.min(currentIndex + 1, items.length - 1)
    } else if (e.key === "ArrowLeft" || e.key === "ArrowUp") {
      newIndex = Math.max(currentIndex - 1, 0)
    }

    if (newIndex !== currentIndex) {
      onChange(items[newIndex].id)
      itemRefs.current.get(items[newIndex].id)?.focus()
    }
  }

  // ============================================================================
  // RENDER
  // ============================================================================

  return (
    <MorphContext.Provider value={{ isMorphed, sliderValue, setSliderValue }}>
      <div
        ref={containerRef}
        className={cn("relative flex items-center gap-1 rounded-full p-1", className)}
        style={{ height: RAIL_HEIGHT }}
        onKeyDown={handleKeyDown}
        role="tablist"
        data-mode={isMorphed ? "slider" : "default"}
      >
        {/* Floating Highlight Follower */}
        <AnimatePresence>
          {targetBounds && (
            <motion.div
              className="pointer-events-none absolute z-0"
              initial={false}
              animate={highlightStyle}
              transition={reduceMotion ? { duration: 0 } : TRANSITION_SPRING}
              style={{
                top: "50%",
                translateY: "-50%",
              }}
            >
              <HighlightBox
                isActive={targetId === activeId}
                isMorphed={isMorphed && targetId === activeId}
                pressing={pressing}
                reduceMotion={reduceMotion}
                sliderValue={sliderValue}
                onSliderChange={(v) => {
                  setSliderValue(v)
                  activeItem?.onSliderChange?.(v)
                }}
              />
            </motion.div>
          )}
        </AnimatePresence>

        {/* Items */}
        {items.map((item) => {
          const isActive = item.id === activeId
          const isHovered = item.id === hoveredId

          return (
            <button
              key={item.id}
              ref={(el) => {
                if (el) itemRefs.current.set(item.id, el)
              }}
              type="button"
              role="tab"
              aria-selected={isActive}
              tabIndex={isActive ? 0 : -1}
              className={cn(
                "relative z-10 flex h-8 items-center gap-2 rounded-full px-3 text-sm font-medium outline-none transition-colors",
                isActive || isHovered ? "text-foreground" : "text-muted-foreground",
              )}
              onMouseEnter={() => setHoveredId(item.id)}
              onMouseLeave={() => setHoveredId(null)}
              onMouseDown={() => setPressing(true)}
              onMouseUp={() => setPressing(false)}
              onClick={() => {
                onChange(item.id)
                setPressing(false)
              }}
            >
              {/* Icon brightens on hover/active */}
              <motion.span
                animate={{
                  scale: isActive || isHovered ? 1.1 : 1,
                  opacity: isActive || isHovered ? 1 : 0.7,
                }}
                transition={reduceMotion ? { duration: 0 } : TRANSITION_FAST}
              >
                {item.icon}
              </motion.span>
              {item.label && <span className="hidden lg:inline">{item.label}</span>}
            </button>
          )
        })}
      </div>
    </MorphContext.Provider>
  )
}

// ============================================================================
// HIGHLIGHT BOX (single DOM node with rotating gradient border)
// ============================================================================

interface HighlightBoxProps {
  isActive: boolean
  isMorphed: boolean
  pressing: boolean
  reduceMotion: boolean
  sliderValue: number
  onSliderChange: (value: number) => void
}

function HighlightBox({ isActive, isMorphed, pressing, reduceMotion, sliderValue, onSliderChange }: HighlightBoxProps) {
  return (
    <motion.div
      className="relative h-full w-full overflow-hidden"
      animate={{
        scale: pressing ? 0.96 : 1,
        borderRadius: isMorphed ? 20 : 9999,
      }}
      transition={reduceMotion ? { duration: 0 } : TRANSITION_FAST}
      style={{ borderRadius: 9999 }}
    >
      {/* Rotating gradient border ring */}
      <div
        className={cn("absolute inset-0 rounded-[inherit]", reduceMotion ? "" : "animate-spin-slow")}
        style={{
          background: `conic-gradient(from var(--angle, 0deg), 
            var(--accent-purple) 0deg, 
            var(--accent-blue) 90deg, 
            var(--accent-pink) 180deg, 
            var(--accent-orange) 270deg, 
            var(--accent-purple) 360deg)`,
          padding: BORDER_WIDTH,
          opacity: isActive ? 0.9 : 0.6,
        }}
      >
        {/* Inner fill - dark glassy */}
        <div
          className="h-full w-full rounded-[inherit]"
          style={{
            background: "rgba(20, 20, 24, 0.85)",
            backdropFilter: "blur(8px)",
            boxShadow: `
              inset 0 2px 4px rgba(255,255,255,0.1),
              inset 0 -2px 4px rgba(0,0,0,0.2),
              0 4px 12px rgba(0,0,0,0.3),
              0 2px 4px rgba(0,0,0,0.2)
            `,
          }}
        />
      </div>

      {/* Slider control when morphed */}
      <AnimatePresence>
        {isMorphed && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="absolute inset-0 flex items-center justify-center p-3"
          >
            <SliderTrack value={sliderValue} onChange={onSliderChange} />
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  )
}

// ============================================================================
// SLIDER TRACK (vertical slider inside morphed highlight)
// ============================================================================

interface SliderTrackProps {
  value: number
  onChange: (value: number) => void
}

function SliderTrack({ value, onChange }: SliderTrackProps) {
  const trackRef = useRef<HTMLDivElement>(null)
  const [dragging, setDragging] = useState(false)

  const updateValue = useCallback(
    (clientY: number) => {
      if (!trackRef.current) return
      const rect = trackRef.current.getBoundingClientRect()
      const y = clientY - rect.top
      const percentage = 100 - Math.max(0, Math.min(100, (y / rect.height) * 100))
      onChange(Math.round(percentage))
    },
    [onChange],
  )

  useEffect(() => {
    if (!dragging) return

    const handleMove = (e: PointerEvent) => updateValue(e.clientY)
    const handleUp = () => setDragging(false)

    window.addEventListener("pointermove", handleMove)
    window.addEventListener("pointerup", handleUp)
    return () => {
      window.removeEventListener("pointermove", handleMove)
      window.removeEventListener("pointerup", handleUp)
    }
  }, [dragging, updateValue])

  return (
    <div
      ref={trackRef}
      className="relative h-full w-3 cursor-pointer rounded-full bg-white/10"
      onPointerDown={(e) => {
        setDragging(true)
        updateValue(e.clientY)
      }}
    >
      {/* Fill */}
      <motion.div
        className="absolute bottom-0 left-0 right-0 rounded-full bg-gradient-to-t from-[var(--accent-purple)] to-[var(--accent-blue)]"
        animate={{ height: `${value}%` }}
        transition={{ type: "spring", stiffness: 300, damping: 30 }}
      />
      {/* Knob */}
      <motion.div
        className="absolute left-1/2 h-5 w-5 -translate-x-1/2 rounded-full border-2 border-white bg-white shadow-lg"
        animate={{ bottom: `calc(${value}% - 10px)` }}
        transition={{ type: "spring", stiffness: 300, damping: 30 }}
        style={{ touchAction: "none" }}
      />
    </div>
  )
}
