"use client"

import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { useSettings } from "@/lib/use-settings"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

interface ActionDeckProps {
  onHit: () => void
  onKick: () => void
  onShove: () => void
  onReset: () => void
  score: number
  shoveUnlockScore?: number
}

export function ActionDeck({ onHit, onKick, onShove, onReset, score, shoveUnlockScore = 50 }: ActionDeckProps) {
  const { settings } = useSettings()
  const isShoveUnlocked = score >= shoveUnlockScore

  const ActionButton = ({
    label,
    onClick,
    disabled,
    variant = "destructive",
    tooltipText,
  }: {
    label: string
    onClick: () => void
    disabled?: boolean
    variant?: "destructive" | "secondary"
    tooltipText?: string
  }) => {
    const button = (
      <motion.div
        whileHover={{ scale: settings.reduceMotion ? 1 : disabled ? 1 : 1.02 }}
        whileTap={{ scale: settings.reduceMotion ? 1 : disabled ? 1 : 0.97 }}
        transition={{ duration: 0.12 }}
        className="w-full"
      >
        <Button
          variant="outline"
          disabled={disabled}
          onClick={onClick}
          className={`h-10 w-full text-xs font-semibold transition-all duration-150 ${
            variant === "destructive"
              ? "border-border bg-transparent hover:border-[var(--accent-red)] hover:bg-[var(--accent-red)] focus-visible:border-[var(--accent-blue)] focus-visible:bg-[var(--accent-blue)] focus-visible:ring-1 focus-visible:ring-[var(--accent-blue-bright)] active:border-[var(--accent-red-bright)] active:bg-[var(--accent-red-bright)] active:shadow-inner"
              : "border-border bg-transparent hover:border-border hover:bg-secondary focus-visible:border-[var(--accent-blue)] focus-visible:ring-1 focus-visible:ring-[var(--accent-blue-bright)]"
          } disabled:opacity-30 disabled:hover:bg-transparent disabled:hover:border-border`}
        >
          {label}
        </Button>
      </motion.div>
    )

    if (tooltipText && disabled) {
      return (
        <TooltipProvider delayDuration={200}>
          <Tooltip>
            <TooltipTrigger asChild>{button}</TooltipTrigger>
            <TooltipContent side="left" className="text-xs font-mono">
              {tooltipText}
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      )
    }

    return button
  }

  return (
    <div className="flex flex-col gap-3">
      <div className="flex items-center gap-2">
        <div className="h-1.5 w-1.5 rounded-full bg-foreground/50" />
        <span className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Combat Deck</span>
      </div>

      <div className="grid grid-cols-2 gap-2.5">
        <ActionButton label="Hit" onClick={onHit} />
        <ActionButton label="Kick" onClick={onKick} />
        <ActionButton
          label="Shove"
          onClick={onShove}
          disabled={!isShoveUnlocked}
          tooltipText={`Unlock by scoring ${shoveUnlockScore}+`}
        />
        <ActionButton label="Reset" onClick={onReset} variant="secondary" />
      </div>
    </div>
  )
}
