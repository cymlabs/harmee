"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { useSettings } from "@/lib/use-settings"
import { cn } from "@/lib/utils"
import Image from "next/image"

export function ConsentPopup() {
  const router = useRouter()
  const { settings, updateSetting } = useSettings()
  const [isExiting, setIsExiting] = useState(false)

  const handleAgree = () => {
    setIsExiting(true)
    setTimeout(() => {
      router.push("/arena")
    }, 300)
  }

  const handleExit = () => {
    setIsExiting(true)
    setTimeout(() => {
      router.push("/bye")
    }, 300)
  }

  return (
    <motion.div
      className="relative z-10 w-[90vw] max-w-sm"
      initial={settings.reduceMotion ? { opacity: 0 } : { opacity: 0, scale: 0.9, y: 20 }}
      animate={isExiting ? { opacity: 0, scale: 0.95, y: -10 } : { opacity: 1, scale: 1, y: 0 }}
      transition={{
        type: "spring",
        stiffness: 300,
        damping: 25,
        duration: settings.reduceMotion ? 0.01 : undefined,
      }}
    >
      {/* Main popup card */}
      <div className="harmee-chamber overflow-hidden rounded-2xl">
        {/* Header with HARME logo */}
        <div className="flex flex-col items-center gap-3 px-6 pt-6 pb-4">
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.1, type: "spring", stiffness: 300, damping: 20 }}
          >
            <Image
              src="/logos/harme-logo.png"
              alt="HARME"
              width={140}
              height={56}
              className="drop-shadow-sm"
              priority
            />
          </motion.div>

          <motion.p
            className="text-balance text-center text-xs leading-relaxed text-muted-foreground"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
          >
            A stress-relief arena where characters react, talk back, and evolve.
          </motion.p>
        </div>

        {/* Settings section */}
        <motion.div
          className="mx-4 mb-4 rounded-xl border border-border/50 bg-secondary/50 p-3"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25 }}
        >
          <div className="flex items-center justify-between py-1">
            <Label htmlFor="mute" className="text-xs text-foreground/80">
              Mute sounds
            </Label>
            <Switch
              id="mute"
              checked={settings.mute}
              onCheckedChange={(checked) => updateSetting("mute", checked)}
              className="scale-90"
            />
          </div>
          <div className="flex items-center justify-between py-1">
            <Label htmlFor="reduce-motion" className="text-xs text-foreground/80">
              Reduce motion
            </Label>
            <Switch
              id="reduce-motion"
              checked={settings.reduceMotion}
              onCheckedChange={(checked) => updateSetting("reduceMotion", checked)}
              className="scale-90"
            />
          </div>
        </motion.div>

        {/* Action buttons */}
        <motion.div
          className="flex gap-2 px-4 pb-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
        >
          <motion.div className="flex-1" whileTap={{ scale: settings.reduceMotion ? 1 : 0.97 }}>
            <Button
              onClick={handleAgree}
              className={cn(
                "h-10 w-full rounded-xl text-sm font-medium",
                "bg-foreground text-background",
                "shadow-[0_2px_8px_rgba(0,0,0,0.12)]",
                "transition-all duration-150",
                "hover:shadow-[0_4px_12px_rgba(0,0,0,0.18)]",
                "active:shadow-[0_1px_4px_rgba(0,0,0,0.1)]",
              )}
            >
              Enter Arena
            </Button>
          </motion.div>
          <motion.div whileTap={{ scale: settings.reduceMotion ? 1 : 0.97 }}>
            <Button
              onClick={handleExit}
              variant="ghost"
              className="h-10 rounded-xl px-4 text-sm text-muted-foreground hover:text-foreground"
            >
              Exit
            </Button>
          </motion.div>
        </motion.div>
      </div>

      {/* Footer attribution */}
      <motion.p
        className="mt-4 text-center font-mono text-[10px] tracking-wider text-muted-foreground/60"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.4 }}
      >
        by CYM LABS inc.
      </motion.p>
    </motion.div>
  )
}
