"use client"

import { Badge } from "@/components/ui/badge"

type Mood = "Calm" | "Annoyed" | "Enraged"

interface ArenaHUDProps {
  mood: Mood
  combo: number
  score: number
  hits: number
}

const moodStyles: Record<Mood, string> = {
  Calm: "bg-secondary/60 text-secondary-foreground font-normal border-border/50",
  Annoyed: "bg-secondary text-secondary-foreground font-medium border-border",
  Enraged: "bg-foreground/10 text-foreground font-semibold border-foreground/20",
}

export function ArenaHUD({ mood, combo, score, hits }: ArenaHUDProps) {
  const maxCombo = 10
  const comboPercentage = Math.min((combo / maxCombo) * 100, 100)

  return (
    <div className="flex w-full items-center justify-between gap-4 rounded-lg border border-border bg-background/80 px-4 py-2.5 backdrop-blur-sm shadow-sm lg:gap-6 lg:px-5">
      {/* Left: Mood chip */}
      <div className="flex items-center gap-2.5">
        <span className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Mood</span>
        <Badge variant="outline" className={`h-6 border px-2.5 text-[11px] ${moodStyles[mood]}`}>
          {mood}
        </Badge>
      </div>

      {/* Middle: Combo meter (thin segmented bar) */}
      <div className="flex flex-1 flex-col gap-1.5 lg:max-w-xs">
        <div className="flex items-center justify-between">
          <span className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Combo</span>
          <span className="font-mono text-[10px] font-semibold text-foreground">
            {combo}/{maxCombo}
          </span>
        </div>
        <div className="flex h-1.5 gap-[2px] overflow-hidden rounded-full bg-border/30">
          {Array.from({ length: maxCombo }).map((_, i) => (
            <div
              key={i}
              className={`h-full flex-1 transition-all duration-200 ${i < combo ? "bg-foreground" : "bg-transparent"}`}
            />
          ))}
        </div>
      </div>

      {/* Right: Session score + Hits count */}
      <div className="flex items-center gap-4 border-l border-border pl-4 lg:gap-5 lg:pl-5">
        <div className="flex flex-col items-end">
          <span className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Score</span>
          <span className="font-mono text-base font-bold leading-none text-foreground lg:text-lg">{score}</span>
        </div>
        <div className="flex flex-col items-end">
          <span className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Hits</span>
          <span className="font-mono text-base font-bold leading-none text-foreground lg:text-lg">{hits}</span>
        </div>
      </div>
    </div>
  )
}
