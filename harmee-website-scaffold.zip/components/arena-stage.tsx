"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useSettings } from "@/lib/use-settings"
import Image from "next/image"

interface ArenaStageProps {
  onHit: () => void
  hitCount: number
}

export function ArenaStage({ onHit, hitCount }: ArenaStageProps) {
  const { settings } = useSettings()
  const [isShaking, setIsShaking] = useState(false)
  const [showImpact, setShowImpact] = useState(false)
  const [reticlePulse, setReticlePulse] = useState(false)

  // External trigger handler
  useEffect(() => {
    const handler = () => {
      triggerImpact()
    }
    const trigger = document.getElementById("stage-hit-trigger")
    if (trigger) {
      trigger.addEventListener("click", handler)
      return () => trigger.removeEventListener("click", handler)
    }
  }, [])

  const triggerImpact = () => {
    onHit()

    if (!settings.reduceMotion) {
      setIsShaking(true)
      setReticlePulse(true)
      setShowImpact(true)

      setTimeout(() => setIsShaking(false), 180)
      setTimeout(() => setReticlePulse(false), 300)
      setTimeout(() => setShowImpact(false), 400)
    }
  }

  return (
    <div className="relative flex h-full w-full items-center justify-center p-4">
      <div className="absolute left-4 top-4 z-20 flex items-center gap-3 lg:left-6 lg:top-6">
        <div className="flex items-center gap-2">
          <Image
            src="/logos/cymlabs-logo.png"
            alt="CYM LABS"
            width={60}
            height={24}
            className="h-5 w-auto opacity-80"
          />
        </div>
        <div className="h-3 w-px bg-border/50" />
        <h2 className="font-mono text-xs font-medium uppercase tracking-wider text-muted-foreground">Stage</h2>
        {settings.liteMode && (
          <Badge variant="outline" className="h-5 text-[10px] font-normal">
            Lite Mode
          </Badge>
        )}
      </div>

      {/* Outer frame card (stage display case) */}
      <motion.div
        animate={
          isShaking && !settings.reduceMotion
            ? {
                x: [0, -2, 2, -1, 1, 0],
                y: [0, -1, 1, 0],
                transition: { duration: 0.18 },
              }
            : {}
        }
        className="relative"
      >
        <Card className="relative h-[480px] w-full max-w-[640px] overflow-hidden border-2 border-border bg-background p-4 shadow-lg lg:h-[560px] lg:max-w-[720px] lg:p-5">
          {/* Inner inset panel (double-border look) */}
          <div className="relative h-full w-full overflow-hidden rounded-md border border-border/50 bg-gradient-to-b from-secondary/10 to-secondary/30">
            {/* Monochrome noise texture overlay */}
            {!settings.liteMode && (
              <div
                className="pointer-events-none absolute inset-0 opacity-[0.04]"
                style={{
                  backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 400 400' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")`,
                }}
              />
            )}

            {/* Vignette */}
            <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_20%,rgba(0,0,0,0.12)_100%)]" />

            {/* Grid dots background */}
            {!settings.liteMode && (
              <div
                className="pointer-events-none absolute inset-0 opacity-[0.06]"
                style={{
                  backgroundImage: `radial-gradient(circle, currentColor 0.5px, transparent 0.5px)`,
                  backgroundSize: "20px 20px",
                }}
              />
            )}

            <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
              <motion.div
                animate={
                  reticlePulse && !settings.reduceMotion
                    ? {
                        scale: [1, 1.12, 1],
                        opacity: [0.5, 0.8, 0.5],
                        transition: { duration: 0.3 },
                      }
                    : {}
                }
                className="relative h-40 w-40 lg:h-48 lg:w-48"
              >
                {/* Outer ring */}
                <div className="absolute inset-0 rounded-full border-[1.5px] border-border/40" />
                {/* Middle ring */}
                <div className="absolute inset-5 rounded-full border border-border/30" />
                {/* Inner ring */}
                <div className="absolute inset-10 rounded-full border border-border/20" />
                {/* Center dot */}
                <div className="absolute left-1/2 top-1/2 h-1.5 w-1.5 -translate-x-1/2 -translate-y-1/2 rounded-full bg-foreground/40" />

                {/* Crosshair lines - extended */}
                <div className="absolute left-1/2 top-0 h-4 w-px -translate-x-1/2 bg-border/40" />
                <div className="absolute bottom-0 left-1/2 h-4 w-px -translate-x-1/2 bg-border/40" />
                <div className="absolute left-0 top-1/2 h-px w-4 -translate-y-1/2 bg-border/40" />
                <div className="absolute right-0 top-1/2 h-px w-4 -translate-y-1/2 bg-border/40" />
              </motion.div>
            </div>

            <div className="absolute left-1/2 top-1/2 z-10 -translate-x-1/2 -translate-y-1/2">
              <motion.div
                animate={
                  !settings.reduceMotion
                    ? {
                        y: [0, -4, 0],
                        transition: {
                          duration: 3.5,
                          repeat: Number.POSITIVE_INFINITY,
                          ease: "easeInOut",
                        },
                      }
                    : {}
                }
                className="flex flex-col items-center gap-3"
              >
                <div className="relative flex h-28 w-28 items-center justify-center rounded-2xl border-2 border-dashed border-border bg-background/70 backdrop-blur-sm lg:h-32 lg:w-32">
                  <Image
                    src="/logos/harme-logo.png"
                    alt="HARME"
                    width={100}
                    height={40}
                    className="h-auto w-20 opacity-90 lg:w-24"
                  />
                </div>
                <p className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground/60">HARMEE_01</p>
              </motion.div>
            </div>

            {/* Impact ripple effect */}
            {showImpact && !settings.liteMode && (
              <motion.div
                initial={{ scale: 0.8, opacity: 0.6 }}
                animate={{ scale: 2.8, opacity: 0 }}
                transition={{ duration: 0.4, ease: "easeOut" }}
                className="absolute left-1/2 top-1/2 h-48 w-48 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-foreground/15"
              />
            )}

            {/* Idle drifting highlight */}
            {!settings.liteMode && !settings.reduceMotion && (
              <motion.div
                className="pointer-events-none absolute inset-0 bg-gradient-to-br from-white/[0.03] via-transparent to-transparent"
                animate={{
                  x: [-30, 30, -30],
                  y: [-15, 15, -15],
                }}
                transition={{
                  duration: 9,
                  repeat: Number.POSITIVE_INFINITY,
                  ease: "easeInOut",
                }}
              />
            )}
          </div>
        </Card>
      </motion.div>

      {/* Hidden trigger button */}
      <button id="stage-hit-trigger" className="sr-only" onClick={triggerImpact} />
    </div>
  )
}
