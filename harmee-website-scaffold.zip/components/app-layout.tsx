"use client"

import { type ReactNode, useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { motion } from "framer-motion"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Menu } from "lucide-react"
import { cn } from "@/lib/utils"

const routes = [
  { name: "Arena", path: "/arena" },
  { name: "My Harmees", path: "/my-harmees" },
  { name: "The Lab", path: "/lab" },
  { name: "Talk To Mee", path: "/talk" },
  { name: "Battle", path: "/battle" },
  { name: "Settings", path: "/settings" },
  { name: "About", path: "/about" },
]

export function AppLayout({ children }: { children: ReactNode }) {
  const pathname = usePathname()
  const [liteMode, setLiteMode] = useState(true)

  return (
    <div className="flex min-h-screen flex-col bg-background">
      {/* Top navigation */}
      <header className="border-b border-border bg-background">
        <div className="flex h-14 items-center justify-between px-4 lg:px-6">
          {/* Left: Logo */}
          <Link href="/arena" className="font-mono text-lg font-bold tracking-tight text-foreground">
            HARMEE
          </Link>

          {/* Center: Desktop tabs */}
          <nav className="hidden items-center gap-1 md:flex">
            {routes.map((route) => (
              <Link key={route.path} href={route.path}>
                <motion.div whileTap={{ scale: 0.97 }} transition={{ duration: 0.12 }}>
                  <Button
                    variant={pathname === route.path ? "secondary" : "ghost"}
                    className={cn(
                      "h-8 px-3 text-xs font-medium transition-colors duration-150",
                      pathname === route.path
                        ? "bg-secondary text-foreground"
                        : "text-muted-foreground hover:text-foreground",
                    )}
                  >
                    {route.name}
                  </Button>
                </motion.div>
              </Link>
            ))}
          </nav>

          {/* Right: Status + Mobile menu */}
          <div className="flex items-center gap-3">
            <Badge
              variant="outline"
              className="cursor-pointer text-xs transition-colors duration-150 hover:bg-secondary"
              onClick={() => setLiteMode(!liteMode)}
            >
              Lite Mode: {liteMode ? "On" : "Off"}
            </Badge>

            {/* Mobile menu */}
            <Sheet>
              <SheetTrigger asChild className="md:hidden">
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  <Menu className="h-4 w-4" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-64 bg-background">
                <div className="flex flex-col gap-2 pt-6">
                  {routes.map((route) => (
                    <Link key={route.path} href={route.path}>
                      <Button
                        variant={pathname === route.path ? "secondary" : "ghost"}
                        className="h-9 w-full justify-start text-sm"
                      >
                        {route.name}
                      </Button>
                    </Link>
                  ))}
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </header>

      {/* Main content */}
      <main className="flex-1">{children}</main>
    </div>
  )
}
