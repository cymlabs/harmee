"use client"

import { motion, AnimatePresence } from "framer-motion"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useSettings } from "@/lib/use-settings"

interface DialoguePanelProps {
  message: string
  choices: string[]
  consequenceHint: string
  showChoices: boolean
  onChoiceSelect: (choice: string) => void
}

export function DialoguePanel({ message, choices, consequenceHint, showChoices, onChoiceSelect }: DialoguePanelProps) {
  const { settings } = useSettings()

  return (
    <div className="flex flex-col gap-3">
      <div className="flex items-center gap-2">
        <div className="h-1.5 w-1.5 rounded-full bg-foreground/50" />
        <span className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Decision Stack</span>
      </div>

      {/* Harmee message bubble */}
      <AnimatePresence mode="wait">
        <motion.div
          key={message}
          initial={{ opacity: 0, y: settings.reduceMotion ? 0 : 6 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0 }}
          transition={{ duration: settings.reduceMotion ? 0 : 0.15, ease: "easeOut" }}
        >
          <Card className="border-border bg-background p-4 shadow-sm">
            <div className="mb-2.5 flex items-center gap-2">
              <div className="h-2 w-2 rounded-full bg-foreground/50 ring-2 ring-foreground/10" />
              <span className="font-mono text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
                Harmee
              </span>
            </div>
            <p className="text-pretty text-sm leading-relaxed text-foreground">{message}</p>
          </Card>
        </motion.div>
      </AnimatePresence>

      {/* Choice chips */}
      <AnimatePresence>
        {showChoices && (
          <motion.div
            initial={{ opacity: 0, y: settings.reduceMotion ? 0 : 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: settings.reduceMotion ? 0 : 0.18, ease: "easeOut" }}
            className="flex flex-col gap-2.5"
          >
            <span className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Your Response</span>
            {choices.map((choice, index) => (
              <motion.div
                key={choice}
                initial={{ opacity: 0, x: settings.reduceMotion ? 0 : -8 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{
                  duration: settings.reduceMotion ? 0 : 0.15,
                  delay: settings.reduceMotion ? 0 : index * 0.05,
                  ease: "easeOut",
                }}
              >
                <motion.div
                  whileHover={{ scale: settings.reduceMotion ? 1 : 1.01 }}
                  whileTap={{ scale: settings.reduceMotion ? 1 : 0.97 }}
                  transition={{ duration: 0.12 }}
                >
                  <Button
                    variant="outline"
                    className="h-9 w-full justify-start rounded-lg border-border bg-transparent px-3.5 text-xs font-normal transition-all duration-150 hover:border-[var(--accent-purple)] hover:bg-[var(--accent-purple)] focus-visible:border-[var(--accent-blue)] focus-visible:bg-[var(--accent-blue)] focus-visible:ring-1 focus-visible:ring-[var(--accent-blue-bright)] active:border-[var(--accent-purple-bright)] active:bg-[var(--accent-purple-bright)]"
                    onClick={() => onChoiceSelect(choice)}
                  >
                    {choice}
                  </Button>
                </motion.div>
              </motion.div>
            ))}

            {/* Consequence hint */}
            {consequenceHint && (
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: settings.reduceMotion ? 0 : 0.2, delay: settings.reduceMotion ? 0 : 0.25 }}
                className="mt-0.5 text-pretty text-[11px] italic leading-relaxed text-muted-foreground/80"
              >
                {consequenceHint}
              </motion.p>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
