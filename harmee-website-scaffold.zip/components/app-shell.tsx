"use client"

import type { ReactNode } from "react"
import Link from "next/link"
import Image from "next/image"
import { usePathname, useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import {
  Menu,
  Volume2,
  VolumeX,
  Zap,
  ZapOff,
  Crosshair,
  Users,
  FlaskConical,
  MessageCircle,
  Swords,
  Settings,
  Info,
  Command,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { useSettings } from "@/lib/use-settings"
import { HarmeeBackground } from "@/components/harmee-background"
import { MagicRail, type MagicRailItem } from "@/components/ui/magic-rail"

const routes: MagicRailItem[] = [
  { id: "/arena", icon: <Crosshair className="h-4 w-4" />, label: "Arena" },
  { id: "/my-harmees", icon: <Users className="h-4 w-4" />, label: "My Harmees" },
  { id: "/lab", icon: <FlaskConical className="h-4 w-4" />, label: "The Lab" },
  { id: "/talk", icon: <MessageCircle className="h-4 w-4" />, label: "Talk" },
  { id: "/battle", icon: <Swords className="h-4 w-4" />, label: "Battle" },
  { id: "/settings", icon: <Settings className="h-4 w-4" />, label: "Settings" },
  { id: "/about", icon: <Info className="h-4 w-4" />, label: "About" },
]

interface AppShellProps {
  children: ReactNode
}

export function AppShell({ children }: AppShellProps) {
  const pathname = usePathname()
  const router = useRouter()
  const { settings, updateSetting } = useSettings()

  const handleNavChange = (id: string) => {
    router.push(id)
  }

  return (
    <div className={cn("relative flex min-h-screen flex-col", settings.reduceMotion && "reduce-motion")}>
      <HarmeeBackground density={settings.liteMode ? "calm" : "active"} />

      {/* Top navigation - premium glass header */}
      <header className="sticky top-0 z-50 border-b border-border/50 bg-[var(--surface-elevated)] backdrop-blur-xl">
        <div className="flex h-14 items-center justify-between px-4 lg:px-6">
          {/* Left: Logo */}
          <Link href="/arena" className="flex items-center gap-2">
            <Image
              src="/logos/harme-logo.png"
              alt="HARME"
              width={100}
              height={32}
              className="h-8 w-auto object-contain"
            />
          </Link>

          <nav className="hidden md:block">
            <MagicRail
              items={routes}
              activeId={pathname}
              onChange={handleNavChange}
              className="bg-[var(--surface-inset)]"
            />
          </nav>

          {/* Right: Global controls */}
          <div className="flex items-center gap-1">
            {/* Command palette hint */}
            <div className="mr-2 hidden items-center gap-1 rounded-md border border-border/50 bg-[var(--surface-inset)] px-2 py-1 text-xs text-muted-foreground lg:flex">
              <Command className="h-3 w-3" />
              <span>K</span>
            </div>

            <Button
              variant="ghost"
              size="icon"
              className="h-9 w-9 text-muted-foreground transition-colors hover:bg-[var(--surface-inset)] hover:text-foreground"
              onClick={() => updateSetting("mute", !settings.mute)}
              aria-label={settings.mute ? "Unmute" : "Mute"}
            >
              {settings.mute ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
            </Button>

            <Button
              variant="ghost"
              size="icon"
              className="h-9 w-9 text-muted-foreground transition-colors hover:bg-[var(--surface-inset)] hover:text-foreground"
              onClick={() => updateSetting("liteMode", !settings.liteMode)}
              aria-label={settings.liteMode ? "Disable Lite Mode" : "Enable Lite Mode"}
            >
              {settings.liteMode ? <ZapOff className="h-4 w-4" /> : <Zap className="h-4 w-4" />}
            </Button>

            {/* Mobile menu */}
            <Sheet>
              <SheetTrigger asChild className="md:hidden">
                <Button variant="ghost" size="icon" className="h-9 w-9">
                  <Menu className="h-4 w-4" />
                </Button>
              </SheetTrigger>
              <SheetContent
                side="right"
                className="w-72 border-l border-border/50 bg-[var(--surface-elevated)] backdrop-blur-xl"
              >
                <div className="flex flex-col gap-1 pt-8">
                  {routes.map((route) => (
                    <Link key={route.id} href={route.id}>
                      <Button
                        variant={pathname === route.id ? "secondary" : "ghost"}
                        className="h-11 w-full justify-start gap-3 text-sm"
                      >
                        {route.icon}
                        {route.label}
                      </Button>
                    </Link>
                  ))}
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </header>

      <main className="relative z-10 flex-1">
        <div className="mx-auto h-full max-w-screen-2xl">{children}</div>
      </main>

      {/* Footer attribution */}
      <footer className="relative z-10 border-t border-border/50 bg-[var(--surface-elevated)]/80 backdrop-blur">
        <div className="flex h-10 items-center justify-center px-4">
          <Link
            href="https://cymlabs.com"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 opacity-60 transition-opacity hover:opacity-100"
          >
            <span className="text-xs text-muted-foreground">Powered by</span>
            <Image
              src="/logos/cymlabs-logo.png"
              alt="CYM LABS"
              width={64}
              height={20}
              className="h-5 w-auto object-contain"
            />
          </Link>
        </div>
      </footer>
    </div>
  )
}
