import { cn } from "@/lib/utils"
import type { ReactNode } from "react"

interface SurfaceCardProps {
  children: ReactNode
  className?: string
}

export function SurfaceCard({ children, className }: SurfaceCardProps) {
  return (
    <div className={cn("rounded-lg border border-border bg-card shadow-[0_1px_3px_rgba(0,0,0,0.04)]", className)}>
      {children}
    </div>
  )
}
