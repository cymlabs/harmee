"use client"

import { useSettings } from "@/lib/use-settings"

interface HarmeeBackgroundProps {
  density?: "calm" | "active" | "impact"
}

export function HarmeeBackground({ density = "calm" }: HarmeeBackgroundProps) {
  const { settings } = useSettings()

  const opacityMap = {
    calm: { blob: 0.08, wave: 0.06 },
    active: { blob: 0.15, wave: 0.12 },
    impact: { blob: 0.25, wave: 0.18 },
  }

  const { blob: blobOpacity, wave: waveOpacity } = opacityMap[density]
  const shouldAnimate = !settings.reduceMotion && !settings.liteMode

  if (settings.liteMode) {
    return <div className="fixed inset-0 z-0 bg-[var(--surface-base)]" />
  }

  return (
    <>
      {/* Base surface */}
      <div className="fixed inset-0 z-0 bg-[var(--surface-base)]" />

      {/* Energy blobs - positioned at corners/edges */}
      <div className="pointer-events-none fixed inset-0 z-0 overflow-hidden">
        {/* Top-left: Purple energy */}
        <div
          className="absolute -left-32 -top-32 h-[500px] w-[500px] rounded-full blur-[80px]"
          style={{
            background: `radial-gradient(circle, var(--accent-purple) 0%, transparent 70%)`,
            opacity: blobOpacity,
            animation: shouldAnimate ? "float-slow 25s ease-in-out infinite" : "none",
          }}
        />

        {/* Top-right: Blue energy */}
        <div
          className="absolute -right-24 -top-24 h-[400px] w-[400px] rounded-full blur-[80px]"
          style={{
            background: `radial-gradient(circle, var(--accent-blue) 0%, transparent 70%)`,
            opacity: blobOpacity * 0.9,
            animation: shouldAnimate ? "float-slow 22s ease-in-out infinite reverse" : "none",
          }}
        />

        {/* Bottom-left: Pink + Orange energy */}
        <div
          className="absolute -bottom-24 -left-24 h-[350px] w-[350px] rounded-full blur-[80px]"
          style={{
            background: `radial-gradient(circle, var(--accent-pink) 0%, var(--accent-orange) 50%, transparent 70%)`,
            opacity: blobOpacity * 0.8,
            animation: shouldAnimate ? "float-slow 28s ease-in-out infinite" : "none",
          }}
        />

        {/* Bottom-right: Purple + Blue energy */}
        <div
          className="absolute -bottom-32 -right-32 h-[450px] w-[450px] rounded-full blur-[80px]"
          style={{
            background: `radial-gradient(circle, var(--accent-purple) 0%, var(--accent-blue) 50%, transparent 70%)`,
            opacity: blobOpacity * 0.85,
            animation: shouldAnimate ? "float-slow 30s ease-in-out infinite reverse" : "none",
          }}
        />

        {/* Center-top: Subtle wave */}
        <div
          className="absolute left-1/2 top-0 h-[300px] w-[800px] -translate-x-1/2 rounded-full blur-[100px]"
          style={{
            background: `radial-gradient(ellipse, var(--accent-pink) 0%, transparent 70%)`,
            opacity: waveOpacity,
            animation: shouldAnimate ? "pulse-glow 12s ease-in-out infinite" : "none",
          }}
        />
      </div>

      {/* Noise texture overlay */}
      <div
        className="pointer-events-none fixed inset-0 z-0 opacity-[0.015]"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E")`,
        }}
      />
    </>
  )
}
