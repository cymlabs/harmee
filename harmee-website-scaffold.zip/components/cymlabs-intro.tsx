"use client"

import { motion } from "framer-motion"
import Image from "next/image"

interface CymLabsIntroProps {
  onComplete: () => void
  skipAnimation?: boolean
}

export function CymLabsIntro({ onComplete, skipAnimation = false }: CymLabsIntroProps) {
  if (skipAnimation) {
    onComplete()
    return null
  }

  return (
    <motion.div
      className="fixed inset-0 z-50 flex items-center justify-center bg-[#FAFAFC]"
      initial={{ opacity: 1 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
    >
      {/* Subtle background pulse */}
      <motion.div
        className="absolute inset-0 bg-gradient-radial from-transparent via-transparent to-[rgba(139,92,246,0.03)]"
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1.2, opacity: 1 }}
        transition={{ duration: 2, ease: "easeOut" }}
      />

      {/* Logo container */}
      <motion.div
        className="relative flex flex-col items-center gap-6"
        initial={{ opacity: 0, scale: 0.8, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{
          duration: 0.6,
          ease: [0.22, 1, 0.36, 1],
          delay: 0.2,
        }}
        onAnimationComplete={() => {
          // Wait for the full sequence then call onComplete
          setTimeout(onComplete, 1200)
        }}
      >
        {/* Logo image with bounce effect */}
        <motion.div
          className="relative"
          initial={{ scale: 0, rotate: -10 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{
            type: "spring",
            stiffness: 260,
            damping: 20,
            delay: 0.3,
          }}
        >
          {/* Glow behind logo */}
          <motion.div
            className="absolute inset-0 -z-10 blur-2xl"
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 0.4, scale: 1.2 }}
            transition={{ duration: 0.8, delay: 0.5 }}
          >
            <div className="h-full w-full rounded-full bg-gradient-to-br from-[rgba(59,130,246,0.3)] via-[rgba(139,92,246,0.3)] to-[rgba(236,72,153,0.3)]" />
          </motion.div>

          <Image
            src="/logos/cymlabs-logo.png"
            alt="CYM LABS"
            width={180}
            height={180}
            className="relative z-10 drop-shadow-lg"
            priority
          />
        </motion.div>

        {/* Tagline with stagger */}
        <motion.div
          className="flex items-center gap-2 font-mono text-sm tracking-widest text-muted-foreground"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.7 }}
        >
          <motion.span initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.8 }}>
            presents
          </motion.span>
        </motion.div>

        {/* Loading dots */}
        <motion.div
          className="flex gap-1.5"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
        >
          {[0, 1, 2].map((i) => (
            <motion.div
              key={i}
              className="h-1.5 w-1.5 rounded-full bg-foreground/30"
              animate={{
                scale: [1, 1.3, 1],
                opacity: [0.3, 1, 0.3],
              }}
              transition={{
                duration: 0.6,
                repeat: Number.POSITIVE_INFINITY,
                delay: i * 0.15,
              }}
            />
          ))}
        </motion.div>
      </motion.div>
    </motion.div>
  )
}
