/**
 * HARMEE Design Token System
 * Following the Design Constitution: Gradient Pop + Soft Brutalism hybrid
 * Monochrome base + CYMLABS accent tokens for interactions only
 */

export const designTokens = {
  // Style genome
  genome: "gradient-pop-soft-brutalism" as const,

  // Surface tokens (layered depth system)
  surfaces: {
    base: "#FAFAFC", // Near-white base
    elevated: "rgba(255, 255, 255, 0.92)", // Cards
    overlay: "rgba(255, 255, 255, 0.96)", // Modals
    inset: "rgba(0, 0, 0, 0.02)", // Recessed areas
  },

  // Monochrome tokens (primary palette)
  colors: {
    mono: {
      white: "#FFFFFF",
      gray98: "#FAFAFC",
      gray95: "#F2F2F4",
      gray90: "#E5E5E8",
      gray70: "#A3A3A8",
      gray50: "#737378",
      gray30: "#4A4A50",
      gray20: "#2D2D32",
      gray10: "#1A1A1E",
      black: "#111114",
    },
    // CYMLABS accent tokens - interaction only, 5-12% opacity
    accent: {
      purple: "rgb(139, 92, 246)", // Primary energy
      purpleGlow: "rgba(139, 92, 246, 0.08)",
      purpleBright: "rgba(139, 92, 246, 0.15)",
      blue: "rgb(59, 130, 246)", // Secondary energy
      blueGlow: "rgba(59, 130, 246, 0.08)",
      blueBright: "rgba(59, 130, 246, 0.15)",
      pink: "rgb(236, 72, 153)", // Tertiary energy
      pinkGlow: "rgba(236, 72, 153, 0.08)",
      pinkBright: "rgba(236, 72, 153, 0.15)",
      orange: "rgb(251, 146, 60)", // Warm accent
      orangeGlow: "rgba(251, 146, 60, 0.08)",
      orangeBright: "rgba(251, 146, 60, 0.15)",
    },
  },

  // Spacing scale (8px grid)
  spacing: {
    "0": "0",
    "1": "0.25rem", // 4px
    "2": "0.5rem", // 8px
    "3": "0.75rem", // 12px
    "4": "1rem", // 16px
    "5": "1.25rem", // 20px
    "6": "1.5rem", // 24px
    "8": "2rem", // 32px
    "10": "2.5rem", // 40px
    "12": "3rem", // 48px
    "16": "4rem", // 64px
  },

  // Typography scale
  typography: {
    scale: {
      xs: ["0.75rem", { lineHeight: "1rem" }], // 12px
      sm: ["0.875rem", { lineHeight: "1.25rem" }], // 14px
      base: ["1rem", { lineHeight: "1.5rem" }], // 16px
      lg: ["1.125rem", { lineHeight: "1.75rem" }], // 18px
      xl: ["1.25rem", { lineHeight: "1.75rem" }], // 20px
      "2xl": ["1.5rem", { lineHeight: "2rem" }], // 24px
      "3xl": ["1.875rem", { lineHeight: "2.25rem" }], // 30px
      "4xl": ["2.25rem", { lineHeight: "2.5rem" }], // 36px
    },
    weight: {
      normal: "400",
      medium: "500",
      semibold: "600",
      bold: "700",
    },
  },

  // Border radius (from constitution)
  radius: {
    sm: "8px", // Pills, chips
    md: "12px", // Buttons, inputs
    lg: "16px", // Cards
    xl: "24px", // Hero sections
    full: "9999px", // Circular
  },

  // Component tokens
  components: {
    button: {
      height: {
        sm: "32px",
        md: "36px",
        lg: "44px",
      },
      radius: "8px",
    },
    card: {
      padding: {
        sm: "12px",
        md: "16px",
        lg: "24px",
      },
      radius: "16px",
      border: "1px solid rgba(0, 0, 0, 0.06)",
      shadow: "0 1px 3px rgba(0, 0, 0, 0.04), 0 1px 2px rgba(0, 0, 0, 0.02)",
    },
    input: {
      height: "40px",
      radius: "10px",
    },
  },

  // Motion signature (from constitution)
  motion: {
    duration: {
      instant: "50ms",
      fast: "120ms",
      base: "180ms",
      moderate: "250ms",
      slow: "400ms",
      slower: "600ms",
    },
    easing: {
      default: [0.4, 0, 0.2, 1], // ease-out
      spring: [0.175, 0.885, 0.32, 1.275], // spring
      inOut: [0.4, 0, 0.6, 1],
      out: [0, 0, 0.2, 1],
    },
    scale: {
      press: 0.97,
      hover: 1.02,
      lift: 1.01,
    },
  },

  // Shadow tokens (layered depth)
  shadows: {
    sm: "0 1px 2px rgba(0, 0, 0, 0.03)",
    base: "0 1px 3px rgba(0, 0, 0, 0.04), 0 1px 2px rgba(0, 0, 0, 0.02)",
    md: "0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03)",
    lg: "0 10px 15px -3px rgba(0, 0, 0, 0.05), 0 4px 6px -2px rgba(0, 0, 0, 0.03)",
    glow: {
      purple: "0 0 20px rgba(139, 92, 246, 0.15)",
      blue: "0 0 20px rgba(59, 130, 246, 0.15)",
      pink: "0 0 20px rgba(236, 72, 153, 0.15)",
    },
  },

  // Background densities
  backgroundDensity: {
    calm: { opacity: 0.08, blur: "80px" },
    active: { opacity: 0.15, blur: "60px" },
    impact: { opacity: 0.25, blur: "40px" },
  },
} as const

export type DesignTokens = typeof designTokens
