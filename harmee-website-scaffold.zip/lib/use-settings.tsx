"use client"

import { createContext, useContext, useEffect, useState, type ReactNode } from "react"

export interface HarmeeSettings {
  mute: boolean
  reduceMotion: boolean
  liteMode: boolean
}

const defaultSettings: HarmeeSettings = {
  mute: false,
  reduceMotion: false,
  liteMode: true,
}

const STORAGE_KEY = "harmee-settings"

interface SettingsContextType {
  settings: HarmeeSettings
  updateSetting: <K extends keyof HarmeeSettings>(key: K, value: HarmeeSettings[K]) => void
  resetSettings: () => void
}

const SettingsContext = createContext<SettingsContextType | undefined>(undefined)

export function SettingsProvider({ children }: { children: ReactNode }) {
  const [settings, setSettings] = useState<HarmeeSettings>(defaultSettings)
  const [mounted, setMounted] = useState(false)

  // Load settings from localStorage on mount
  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY)
    if (stored) {
      try {
        const parsed = JSON.parse(stored) as HarmeeSettings
        setSettings({ ...defaultSettings, ...parsed })
      } catch {
        // Failed to parse, use defaults
      }
    }
    setMounted(true)
  }, [])

  // Save settings to localStorage whenever they change
  useEffect(() => {
    if (mounted) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(settings))

      // Apply reduce-motion to document
      if (settings.reduceMotion) {
        document.documentElement.classList.add("reduce-motion")
      } else {
        document.documentElement.classList.remove("reduce-motion")
      }
    }
  }, [settings, mounted])

  const updateSetting = <K extends keyof HarmeeSettings>(key: K, value: HarmeeSettings[K]) => {
    setSettings((prev) => ({ ...prev, [key]: value }))
  }

  const resetSettings = () => {
    setSettings(defaultSettings)
    localStorage.removeItem(STORAGE_KEY)
  }

  return (
    <SettingsContext.Provider value={{ settings, updateSetting, resetSettings }}>{children}</SettingsContext.Provider>
  )
}

export function useSettings(): SettingsContextType {
  const context = useContext(SettingsContext)
  if (!context) {
    // Return a safe fallback instead of throwing
    return {
      settings: defaultSettings,
      updateSetting: () => {},
      resetSettings: () => {},
    }
  }
  return context
}
